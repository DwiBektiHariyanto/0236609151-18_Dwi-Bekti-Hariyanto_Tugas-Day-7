package com.bekti.mobile_aplikasi;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import androidx.appcompat.app.AlertDialog;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.os.Bundle;

public class IsianNama extends AppCompatActivity {
    EditText txtNama;
    Button btnSubmit,btnClear,btnKalkulator ;
    Intent pindah;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_isian_nama);
        txtNama = findViewById(R.id.editnama);

        btnSubmit = findViewById(R.id.submitbtn);
        btnClear = (Button) findViewById(R.id.resetbtn);
        btnKalkulator= findViewById(R.id.kalkulator_app);
        btnSubmit.setOnClickListener(new View.OnClickListener()

            {
                @Override
                public void onClick (View v){
                String Nama, Alamat;
                if (txtNama.getText().toString().equals("")) {
                    Toast.makeText(IsianNama.this, "Silahkan Isikan Nama Anda", Toast.LENGTH_LONG).show();
                    txtNama.requestFocus();
                } else {
                    Nama = txtNama.getText().toString();

                    Toast.makeText(IsianNama.this, "Selamat Datang" + Nama , Toast.LENGTH_LONG).show();
                }
            }
            });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtNama.setText("");

            }
        });
        btnKalkulator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                pindah = new Intent(IsianNama.this, Kalkulator.class);
                startActivity(pindah);
                finish();

            }
        });

        }


    }

