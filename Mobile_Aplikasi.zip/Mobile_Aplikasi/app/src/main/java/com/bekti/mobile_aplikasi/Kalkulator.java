package com.bekti.mobile_aplikasi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.List;

public class Kalkulator extends AppCompatActivity {
    Button btnListView ;
    Intent pindah;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kalkulator);
        btnListView= findViewById(R.id.list_view);
        btnListView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                pindah = new Intent(Kalkulator.this, List_View.class);
                startActivity(pindah);
                finish();

            }
        });
    }
}