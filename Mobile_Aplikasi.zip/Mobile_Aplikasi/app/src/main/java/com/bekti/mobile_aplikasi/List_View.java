package com.bekti.mobile_aplikasi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class List_View extends AppCompatActivity {
    ListView lvData;
    String[] data = new String[]{"indonesia","my","gjgkj"};
    private ListAdapter adapterData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);
        lvData = findViewById(R.id.lvdata);
        ArrayAdapter<String> AdapterData = new ArrayAdapter<String>(List_View.this,android.R.layout.simple_list_item_1,data);
        lvData.setAdapter(adapterData);
        lvData.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(List_View.this,"Data Hewan yang dipilih adalah:" +data[i],Toast.LENGTH_LONG).show();
            }
        });
    }
}